@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Instalador AudioBridge v2 - FL Studio

:: Comprobar si se está ejecutando como Administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Solicitando permisos de administrador...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

echo ======================================================================
echo                 INSTALADOR AUTOMÁTICO AUDIOBRIDGE v2
echo ======================================================================
echo.

set "DEST_VST3=C:\Program Files\Common Files\VST3\AudioBridge v2.vst3"
set "SOURCE_VST3=%~dp0AudioBridge v2.vst3"
set "SOURCE_EXE=%~dp0AudioBridge_v2_Receiver.exe"

if not exist "%SOURCE_VST3%" (
    echo [ERROR] No se encuentra la carpeta "AudioBridge v2.vst3" en este directorio.
    echo Asegúrate de extraer todo el contenido antes de ejecutar el instalador.
    pause
    exit /b 1
)

echo [1/3] Preparando la carpeta VST3 estándar de Windows...
if not exist "C:\Program Files\Common Files\VST3" (
    mkdir "C:\Program Files\Common Files\VST3"
)

echo [2/3] Instalando el plugin VST3 en:
echo       "%DEST_VST3%"...
if exist "%DEST_VST3%" (
    rmdir /S /Q "%DEST_VST3%" >nul 2>&1
)
xcopy /E /I /Y /Q "%SOURCE_VST3%" "%DEST_VST3%" >nul
if %errorlevel% neq 0 (
    echo [ERROR] No se pudo copiar el plugin a C:\Program Files\Common Files\VST3.
    echo Verifica que tu DAW (FL Studio) esté cerrado.
    pause
    exit /b 1
)

echo [3/3] Colocando el Receptor de Audio en tu Escritorio...
if exist "%SOURCE_EXE%" (
    copy /Y "%SOURCE_EXE%" "%USERPROFILE%\Desktop\AudioBridge_v2_Receiver.exe" >nul
)

echo.
echo ======================================================================
echo                   ¡INSTALACIÓN COMPLETADA CON ÉXITO!
echo ======================================================================
echo.
echo  1. El plugin VST3 ya está instalado en:
echo     C:\Program Files\Common Files\VST3\AudioBridge v2.vst3
echo.
echo  2. Tienes el ejecutable listo en tu Escritorio:
echo     "AudioBridge_v2_Receiver.exe"
echo.
echo  Pasos en tu DAW (FL Studio):
echo  - Abre FL Studio.
echo  - Ve a: Options ^> Manage plugins y pulsa "Find installed plugins".
echo  - Añade "AudioBridge v2" en el canal MASTER del Mixer.
echo  - Abre "AudioBridge_v2_Receiver.exe", selecciona tus cascos y ¡listo!
echo.
echo ======================================================================
pause
