@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Desinstalador AudioBridge v2

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Solicitando permisos de administrador...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

echo ======================================================================
echo                 DESINSTALADOR AUDIOBRIDGE v2
echo ======================================================================
echo.

set "DEST_VST3=C:\Program Files\Common Files\VST3\AudioBridge v2.vst3"

if exist "%DEST_VST3%" (
    echo Eliminando plugin VST3 de:
    echo "%DEST_VST3%"...
    rmdir /S /Q "%DEST_VST3%" >nul 2>&1
    echo Plugin eliminado correctamente.
) else (
    echo No se encontró el plugin instalado en la ruta estándar.
)

echo.
echo ======================================================================
echo Desinstalación finalizada.
echo ======================================================================
pause
